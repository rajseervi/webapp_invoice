import ThemeToggle from './ThemeToggle';

export default ThemeToggle;