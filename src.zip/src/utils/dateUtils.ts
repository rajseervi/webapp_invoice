export function formatDate(date: string | Date) {
  // ... date formatting implementation ...
}

// export function formatDateTime(date: string | Date) {
//   // ... datetime formatting implementation ...
// }


export function formatDateTime(date: string | Date) {
  // ... datetime formatting implementation ...
}