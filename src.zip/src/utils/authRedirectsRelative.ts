// Re-export all functions from the original file
export * from './authRedirects';