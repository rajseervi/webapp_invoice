"use client";
import { SidebarDemo } from '@/components/ModernSidebar';

export default function SidebarDemoPage() {
  return <SidebarDemo />;
}