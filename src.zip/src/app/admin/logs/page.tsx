"use client"
import React, { useState, useEffect } from 'react';
import DashboardLayout from '@/components/DashboardLayout';
import {
  Container,
  Typography,
  Paper,
  Box,
  TextField,
  InputAdornment,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  Chip,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Button,
  Alert,
  CircularProgress,
  IconButton,
  Tooltip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions
} from '@mui/material';
import {
  Search as SearchIcon,
  FilterList as FilterListIcon,
  Refresh as RefreshIcon,
  Delete as DeleteIcon,
  Info as InfoIcon,
  Download as DownloadIcon
} from '@mui/icons-material';
import { collection, getDocs, query, where, orderBy, limit, startAfter, Timestamp } from 'firebase/firestore';
import { db } from '@/firebase/config';
import { useAuth } from '@/contexts/AuthContext';
import { useRouter } from 'next/navigation';

// Define interfaces
interface SystemLog {
  id: string;
  action: string;
  userId: string;
  userName: string;
  userEmail: string;
  timestamp: Timestamp;
  details: string;
  module: string;
  level: 'info' | 'warning' | 'error';
  ipAddress?: string;
  metadata?: Record<string, any>;
}

export default function SystemLogsPage() {
  const router = useRouter();
  const { userRole } = useAuth();
  
  const [logs, setLogs] = useState<SystemLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedLog, setSelectedLog] = useState<SystemLog | null>(null);
  const [openLogDialog, setOpenLogDialog] = useState(false);
  
  // Pagination state
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [totalCount, setTotalCount] = useState(0);
  const [lastVisible, setLastVisible] = useState<any>(null);
  
  // Filter state
  const [levelFilter, setLevelFilter] = useState<string>('');
  const [moduleFilter, setModuleFilter] = useState<string>('');
  const [dateFilter, setDateFilter] = useState<string>('');
  
  // Check if user has admin role
  useEffect(() => {
    if (userRole !== 'admin') {
      router.push('/unauthorized');
    }
  }, [userRole, router]);

  // Fetch logs
  useEffect(() => {
    fetchLogs();
  }, [page, rowsPerPage, levelFilter, moduleFilter, dateFilter]);

  const fetchLogs = async (reset = false) => {
    try {
      setLoading(true);
      
      // Base collection reference
      const logsRef = collection(db, 'systemLogs');
      
      // Build query constraints
      let queryConstraints = [];
      
      // Add filters if specified
      if (levelFilter) {
        queryConstraints.push(where('level', '==', levelFilter));
      }
      
      if (moduleFilter) {
        queryConstraints.push(where('module', '==', moduleFilter));
      }
      
      if (dateFilter) {
        // Convert date string to start and end of day timestamps
        const selectedDate = new Date(dateFilter);
        const startOfDay = new Date(selectedDate.setHours(0, 0, 0, 0));
        const endOfDay = new Date(selectedDate.setHours(23, 59, 59, 999));
        
        queryConstraints.push(where('timestamp', '>=', Timestamp.fromDate(startOfDay)));
        queryConstraints.push(where('timestamp', '<=', Timestamp.fromDate(endOfDay)));
      }
      
      // Add ordering
      queryConstraints.push(orderBy('timestamp', 'desc'));
      
      // Add pagination constraints
      if (!reset && lastVisible) {
        queryConstraints.push(startAfter(lastVisible));
      }
      
      // Add limit
      queryConstraints.push(limit(rowsPerPage));
      
      // Create the query
      const logsQuery = query(logsRef, ...queryConstraints);
      
      const logsSnapshot = await getDocs(logsQuery);
      
      // Store the last visible document for pagination
      const lastVisibleDoc = logsSnapshot.docs[logsSnapshot.docs.length - 1];
      setLastVisible(lastVisibleDoc);
      
      // Map the documents to our log objects
      const logsList = logsSnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          action: data.action,
          userId: data.userId,
          userName: data.userName,
          userEmail: data.userEmail,
          timestamp: data.timestamp,
          details: data.details,
          module: data.module,
          level: data.level,
          ipAddress: data.ipAddress,
          metadata: data.metadata
        };
      });
      
      // Filter by search term if provided
      const filteredLogs = searchTerm
        ? logsList.filter(log =>
            log.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
            log.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
            log.userEmail.toLowerCase().includes(searchTerm.toLowerCase()) ||
            log.details.toLowerCase().includes(searchTerm.toLowerCase())
          )
        : logsList;
      
      setLogs(filteredLogs);
      setError(null);
    } catch (err: any) {
      console.error('Error fetching logs:', err);
      setError('Failed to fetch system logs. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  // Handle page change
  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage);
  };

  // Handle rows per page change
  const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  // Handle search
  const handleSearch = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(event.target.value);
  };

  // Handle filter changes
  const handleLevelFilterChange = (event: any) => {
    setLevelFilter(event.target.value);
    setPage(0);
  };

  const handleModuleFilterChange = (event: any) => {
    setModuleFilter(event.target.value);
    setPage(0);
  };

  const handleDateFilterChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setDateFilter(event.target.value);
    setPage(0);
  };

  // Reset filters
  const handleResetFilters = () => {
    setLevelFilter('');
    setModuleFilter('');
    setDateFilter('');
    setSearchTerm('');
    setPage(0);
  };

  // View log details
  const handleViewLogDetails = (log: SystemLog) => {
    setSelectedLog(log);
    setOpenLogDialog(true);
  };

  // Close log dialog
  const handleCloseLogDialog = () => {
    setOpenLogDialog(false);
  };

  // Format timestamp
  const formatTimestamp = (timestamp: Timestamp) => {
    const date = timestamp.toDate();
    return date.toLocaleString();
  };

  // Get chip color based on log level
  const getLevelChipColor = (level: string) => {
    switch (level) {
      case 'error':
        return 'error';
      case 'warning':
        return 'warning';
      case 'info':
      default:
        return 'info';
    }
  };

  // Get unique modules for filter
  const modules = Array.from(new Set(logs.map(log => log.module)));

  return (
    <DashboardLayout>
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
          <Typography variant="h4" gutterBottom>
            System Logs
          </Typography>
          <Button
            variant="outlined"
            startIcon={<DownloadIcon />}
            onClick={() => alert('Export functionality would be implemented here')}
          >
            Export Logs
          </Button>
        </Box>
        
        {error && (
          <Alert severity="error" sx={{ mb: 3 }}>
            {error}
          </Alert>
        )}
        
        <Paper sx={{ p: 2, mb: 3 }}>
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2, mb: 3 }}>
            <TextField
              label="Search Logs"
              variant="outlined"
              size="small"
              value={searchTerm}
              onChange={handleSearch}
              sx={{ flexGrow: 1, minWidth: '200px' }}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon />
                  </InputAdornment>
                ),
              }}
            />
            
            <FormControl size="small" sx={{ minWidth: '150px' }}>
              <InputLabel id="level-filter-label">Level</InputLabel>
              <Select
                labelId="level-filter-label"
                value={levelFilter}
                label="Level"
                onChange={handleLevelFilterChange}
              >
                <MenuItem value="">All Levels</MenuItem>
                <MenuItem value="info">Info</MenuItem>
                <MenuItem value="warning">Warning</MenuItem>
                <MenuItem value="error">Error</MenuItem>
              </Select>
            </FormControl>
            
            <FormControl size="small" sx={{ minWidth: '150px' }}>
              <InputLabel id="module-filter-label">Module</InputLabel>
              <Select
                labelId="module-filter-label"
                value={moduleFilter}
                label="Module"
                onChange={handleModuleFilterChange}
              >
                <MenuItem value="">All Modules</MenuItem>
                {modules.map(module => (
                  <MenuItem key={module} value={module}>{module}</MenuItem>
                ))}
              </Select>
            </FormControl>
            
            <TextField
              label="Date"
              type="date"
              size="small"
              value={dateFilter}
              onChange={handleDateFilterChange}
              InputLabelProps={{ shrink: true }}
              sx={{ minWidth: '150px' }}
            />
            
            <Button
              variant="outlined"
              startIcon={<RefreshIcon />}
              onClick={handleResetFilters}
            >
              Reset
            </Button>
          </Box>
          
          <TableContainer>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>Timestamp</TableCell>
                  <TableCell>Action</TableCell>
                  <TableCell>User</TableCell>
                  <TableCell>Module</TableCell>
                  <TableCell>Level</TableCell>
                  <TableCell>Details</TableCell>
                  <TableCell>Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {loading && logs.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} align="center">
                      <CircularProgress size={24} sx={{ mr: 1 }} />
                      Loading logs...
                    </TableCell>
                  </TableRow>
                ) : logs.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} align="center">
                      No logs found
                    </TableCell>
                  </TableRow>
                ) : (
                  logs.map((log) => (
                    <TableRow key={log.id}>
                      <TableCell>{formatTimestamp(log.timestamp)}</TableCell>
                      <TableCell>{log.action}</TableCell>
                      <TableCell>
                        <Tooltip title={log.userEmail}>
                          <span>{log.userName}</span>
                        </Tooltip>
                      </TableCell>
                      <TableCell>{log.module}</TableCell>
                      <TableCell>
                        <Chip 
                          label={log.level} 
                          color={getLevelChipColor(log.level) as any} 
                          size="small" 
                          variant="outlined"
                        />
                      </TableCell>
                      <TableCell>
                        {log.details.length > 50 
                          ? `${log.details.substring(0, 50)}...` 
                          : log.details}
                      </TableCell>
                      <TableCell>
                        <IconButton 
                          size="small" 
                          onClick={() => handleViewLogDetails(log)}
                        >
                          <InfoIcon fontSize="small" />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </TableContainer>
          
          <TablePagination
            component="div"
            count={totalCount}
            page={page}
            onPageChange={handleChangePage}
            rowsPerPage={rowsPerPage}
            onRowsPerPageChange={handleChangeRowsPerPage}
            rowsPerPageOptions={[10, 25, 50]}
          />
        </Paper>
      </Container>
      
      {/* Log Details Dialog */}
      <Dialog open={openLogDialog} onClose={handleCloseLogDialog} maxWidth="md" fullWidth>
        <DialogTitle>Log Details</DialogTitle>
        <DialogContent dividers>
          {selectedLog && (
            <Box sx={{ p: 1 }}>
              <Typography variant="subtitle1" gutterBottom>
                Action: {selectedLog.action}
              </Typography>
              <Typography variant="body2" gutterBottom>
                Timestamp: {formatTimestamp(selectedLog.timestamp)}
              </Typography>
              <Typography variant="body2" gutterBottom>
                User: {selectedLog.userName} ({selectedLog.userEmail})
              </Typography>
              <Typography variant="body2" gutterBottom>
                Module: {selectedLog.module}
              </Typography>
              <Typography variant="body2" gutterBottom>
                Level: 
                <Chip 
                  label={selectedLog.level} 
                  color={getLevelChipColor(selectedLog.level) as any} 
                  size="small" 
                  variant="outlined"
                  sx={{ ml: 1 }}
                />
              </Typography>
              
              <Typography variant="subtitle1" sx={{ mt: 2 }}>
                Details:
              </Typography>
              <Paper variant="outlined" sx={{ p: 2, mt: 1, bgcolor: 'background.default' }}>
                <Typography variant="body2" component="pre" sx={{ whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>
                  {selectedLog.details}
                </Typography>
              </Paper>
              
              {selectedLog.ipAddress && (
                <Typography variant="body2" sx={{ mt: 2 }}>
                  IP Address: {selectedLog.ipAddress}
                </Typography>
              )}
              
              {selectedLog.metadata && Object.keys(selectedLog.metadata).length > 0 && (
                <>
                  <Typography variant="subtitle1" sx={{ mt: 2 }}>
                    Additional Metadata:
                  </Typography>
                  <Paper variant="outlined" sx={{ p: 2, mt: 1, bgcolor: 'background.default' }}>
                    <Typography variant="body2" component="pre" sx={{ whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>
                      {JSON.stringify(selectedLog.metadata, null, 2)}
                    </Typography>
                  </Paper>
                </>
              )}
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseLogDialog}>Close</Button>
        </DialogActions>
      </Dialog>
    </DashboardLayout>
  );
}