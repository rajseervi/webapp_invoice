
const connectorConfig = {
  connector: 'default',
  service: 'mastermind',
  location: 'us-central1'
};
exports.connectorConfig = connectorConfig;
