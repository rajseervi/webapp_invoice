#!/bin/bash

# Make backup of original files
cp /Users/prakashseervi/Desktop/mastermind/src/components/DashboardLayout/DashboardLayout.tsx /Users/prakashseervi/Desktop/mastermind/src/components/DashboardLayout/DashboardLayout.tsx.bak
cp /Users/prakashseervi/Desktop/mastermind/src/components/DashboardLayout/ImprovedNavigation.tsx /Users/prakashseervi/Desktop/mastermind/src/components/DashboardLayout/ImprovedNavigation.tsx.bak

# Replace with responsive versions
cp /Users/prakashseervi/Desktop/mastermind/src/components/DashboardLayout/DashboardLayout.responsive.tsx /Users/prakashseervi/Desktop/mastermind/src/components/DashboardLayout/DashboardLayout.tsx
cp /Users/prakashseervi/Desktop/mastermind/src/components/DashboardLayout/ImprovedNavigation.responsive.tsx /Users/prakashseervi/Desktop/mastermind/src/components/DashboardLayout/ImprovedNavigation.tsx

echo "Responsive layout files have been updated!"#!/bin/bash

# Make backup of original files
cp /Users/prakashseervi/Desktop/mastermind/src/components/DashboardLayout/DashboardLayout.tsx /Users/prakashseervi/Desktop/mastermind/src/components/DashboardLayout/DashboardLayout.tsx.bak
cp /Users/prakashseervi/Desktop/mastermind/src/components/DashboardLayout/ImprovedNavigation.tsx /Users/prakashseervi/Desktop/mastermind/src/components/DashboardLayout/ImprovedNavigation.tsx.bak

# Replace with responsive versions
cp /Users/prakashseervi/Desktop/mastermind/src/components/DashboardLayout/DashboardLayout.responsive.tsx /Users/prakashseervi/Desktop/mastermind/src/components/DashboardLayout/DashboardLayout.tsx
cp /Users/prakashseervi/Desktop/mastermind/src/components/DashboardLayout/ImprovedNavigation.responsive.tsx /Users/prakashseervi/Desktop/mastermind/src/components/DashboardLayout/ImprovedNavigation.tsx

echo "Responsive layout files have been updated!"